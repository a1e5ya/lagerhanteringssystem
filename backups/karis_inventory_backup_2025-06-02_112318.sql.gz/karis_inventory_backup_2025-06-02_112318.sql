-- Database Backup for ka_lagerhanteringssystem
-- Generated on: 2025-06-02 11:23:18
-- 

SET FOREIGN_KEY_CHECKS = 0;

-- 
-- Table structure for table `author`
-- 

DROP TABLE IF EXISTS `author`;
CREATE TABLE `author` (
  `author_id` int NOT NULL AUTO_INCREMENT,
  `author_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `author`
-- 

INSERT INTO `author` (`author_id`, `author_name`) VALUES
('1', 'Väinö Linna'),
('2', 'Mika Waltari'),
('3', 'Aleksis Kivi'),
('4', 'Sofi Oksanen'),
('5', 'Arto Paasilinna'),
('6', 'Astrid Lindgren'),
('7', 'Stieg Larsson'),
('8', 'Henning Mankell'),
('9', 'Tove Jansson'),
('10', 'Agatha Christie'),
('11', 'Arthur Conan Doyle'),
('12', 'J.R.R. Tolkien'),
('13', 'George Orwell'),
('14', 'Jane Austen'),
('15', 'Charles Dickens'),
('16', 'William Shakespeare'),
('17', 'Ernest Hemingway'),
('18', 'F. Scott Fitzgerald'),
('19', 'Harper Lee'),
('20', 'Mark Twain'),
('21', 'Leo Tolstoy'),
('22', 'Fyodor Dostoevsky'),
('23', 'Franz Kafka'),
('24', 'Virginia Woolf'),
('25', 'James Joyce'),
('26', 'Roald Dahl'),
('27', 'Lewis Carroll'),
('28', 'C.S. Lewis'),
('29', 'Ray Bradbury'),
('30', 'Isaac Asimov'),
('31', 'Jean Sibelius'),
('32', 'The Beatles'),
('33', 'Elvis Presley'),
('34', 'Bob Dylan'),
('35', 'ABBA'),
('36', 'Pink Floyd'),
('37', 'Queen'),
('38', 'Led Zeppelin'),
('39', 'David Bowie'),
('40', 'The Rolling Stones'),
('41', 'Juice Leskinen'),
('42', 'Eppu Normaali'),
('43', 'Dingo'),
('44', 'Hassisen Kone'),
('45', 'Leevi and the Leavings'),
('46', 'Aki Kaurismäki'),
('47', 'Ingmar Bergman'),
('48', 'Steven Spielberg'),
('49', 'Christopher Nolan'),
('50', 'Alfred Hitchcock'),
('51', 'Hergé'),
('52', 'René Goscinny'),
('53', 'Albert Uderzo'),
('54', 'Carl Barks'),
('55', 'Don Rosa'),
('56', 'Stan Lee'),
('57', 'Jack Kirby'),
('58', 'Alan Moore'),
('59', 'Frank Miller'),
('60', 'Neil Gaiman'),
('61', 'Art Spiegelman'),
('62', 'Marjane Satrapi'),
('63', 'Mauri Kunnas'),
('64', 'Turk'),
('65', 'Peyo'),
('66', 'Aleksandra M'),
('67', 'ggg'),
('68', 'Aleksandra Maurina');

-- 
-- Table structure for table `backup_metadata`
-- 

DROP TABLE IF EXISTS `backup_metadata`;
CREATE TABLE `backup_metadata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) NOT NULL,
  `hidden` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filename` (`filename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table `backup_metadata`
-- 

INSERT INTO `backup_metadata` (`id`, `filename`, `hidden`, `created_at`, `updated_at`) VALUES
('1', 'karis_inventory_backup_2025-06-02_111011.sql.gz', '1', '2025-06-02 11:22:16', '2025-06-02 11:22:16');

-- 
-- Table structure for table `category`
-- 

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `category_sv_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `category_fi_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_name` (`category_sv_name`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `category`
-- 

INSERT INTO `category` (`category_id`, `category_sv_name`, `category_fi_name`) VALUES
('1', 'Bok', 'Kirja'),
('5', 'CD', 'CD'),
('6', 'Vinyl', 'Vinyyli'),
('7', 'DVD', 'DVD'),
('8', 'Serier', 'Sarjakuva'),
('9', 'Samlarobjekt', 'Keräilyesine'),
('12', 'Spel', 'Pelit'),
('13', 'Tidningar', 'Lehdet');

-- 
-- Table structure for table `condition`
-- 

DROP TABLE IF EXISTS `condition`;
CREATE TABLE `condition` (
  `condition_id` int NOT NULL AUTO_INCREMENT,
  `condition_sv_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `condition_fi_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `condition_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`condition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `condition`
-- 

INSERT INTO `condition` (`condition_id`, `condition_sv_name`, `condition_fi_name`, `condition_code`) VALUES
('1', 'Nyskick', 'Erinomainen', 'K-4'),
('2', 'Mycket bra', 'Erittäin hyvä', 'K-3'),
('3', 'Bra', 'Hyvä', 'K-2'),
('4', 'Acceptabelt', 'Hyväksyttävä', 'K-1');

-- 
-- Table structure for table `event_log`
-- 

DROP TABLE IF EXISTS `event_log`;
CREATE TABLE `event_log` (
  `event_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `event_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `event_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `event_timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  `product_id` int DEFAULT NULL,
  PRIMARY KEY (`event_id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `event_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `event_log_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`prod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `event_log`
-- 

INSERT INTO `event_log` (`event_id`, `user_id`, `event_type`, `event_description`, `event_timestamp`, `product_id`) VALUES
('1', NULL, 'create', 'Skapade produkt: Trollvinter', '2025-04-22 11:21:34', NULL),
('2', NULL, 'create', 'Skapade produkt: Muumipeikko ja pyrstötähti', '2025-04-22 11:21:34', NULL),
('3', NULL, 'update', 'Uppdaterade pris på: Harry Potter och De Vises Sten', '2025-04-22 11:21:34', NULL),
('4', NULL, 'create', 'Skapade produkt: Sibelius Symphony No. 2', '2025-04-22 11:21:34', NULL),
('5', NULL, 'login', 'Backdoor login used for admin', '2025-05-12 10:53:38', NULL),
('198', '1', 'logout', 'User logged out: admin', '2025-05-15 13:30:36', NULL),
('199', '1', 'login', 'Backdoor login used for admin', '2025-05-15 13:30:52', NULL),
('200', '1', 'logout', 'User logged out: admin', '2025-05-19 12:22:24', NULL),
('201', '1', 'login', 'Backdoor login used for admin', '2025-05-19 12:22:33', NULL),
('202', '1', 'logout', 'User logged out: admin', '2025-05-19 12:23:19', NULL),
('203', '1', 'logout', 'User logged out: Admin', '2025-05-27 08:58:34', NULL),
('204', '1', 'login', 'Successful login for user: Admin', '2025-05-27 10:41:47', NULL),
('205', '1', 'logout', 'User logged out: Admin', '2025-05-27 11:01:50', NULL),
('206', '1', 'login', 'Successful login for user: Admin', '2025-05-27 11:01:55', NULL),
('211', '1', 'batch_update_status', 'Batch operation: 30 produkter har fått ny status.', '2025-05-27 12:38:20', NULL),
('212', '1', 'batch_update_status', 'Batch operation: 30 produkter har fått ny status.', '2025-05-27 12:38:20', NULL),
('213', '1', 'batch_delete', 'Batch operation: 3 produkter har tagits bort.', '2025-05-27 12:38:33', NULL),
('214', '1', 'batch_delete', 'Batch operation: 3 produkter har tagits bort.', '2025-05-27 12:38:33', NULL),
('215', '1', 'batch_set_rare', 'Batch operation: 2 produkter markerade som sällsynta.', '2025-05-27 12:38:37', NULL),
('216', '1', 'batch_set_rare', 'Batch operation: 2 produkter markerade som sällsynta.', '2025-05-27 12:38:37', NULL),
('217', '1', 'batch_update_price', 'Batch operation: 6 produkter uppdaterade med nytt pris.', '2025-05-27 12:38:47', NULL),
('218', '1', 'batch_update_price', 'Batch operation: 6 produkter uppdaterade med nytt pris.', '2025-05-27 12:38:47', NULL),
('221', '1', 'logout', 'User logged out: Admin', '2025-05-27 12:52:55', NULL),
('222', '1', 'login', 'Successful login for user: Admin', '2025-05-27 12:53:00', NULL),
('224', '1', 'batch_set_rare', 'Batch operation: 21 produkter markerade som sällsynta.', '2025-05-27 12:54:23', NULL),
('225', '1', 'batch_set_rare', 'Batch operation: 21 produkter markerade som sällsynta.', '2025-05-27 12:54:23', NULL),
('226', '1', 'batch_set_rare', 'Batch operation: 21 produkter tog bort sällsynt-markeringen från.', '2025-05-27 12:54:28', NULL),
('227', '1', 'batch_set_rare', 'Batch operation: 21 produkter tog bort sällsynt-markeringen från.', '2025-05-27 12:54:28', NULL),
('228', '1', 'logout', 'User logged out: Admin', '2025-05-27 12:56:42', NULL),
('229', '1', 'login', 'Successful login for user: Admin', '2025-05-27 12:56:47', NULL),
('230', '1', 'update_subscriber', 'Newsletter subscriber deactivated (ID: 19)', '2025-05-27 12:59:46', NULL),
('231', '1', 'delete_subscriber', 'Newsletter subscriber deleted: lesya.maurin@gmail.com', '2025-05-27 13:00:19', NULL),
('232', '1', 'update_subscriber', 'Newsletter subscriber deactivated (ID: 1)', '2025-05-27 13:01:02', NULL),
('233', '1', 'create_author', 'Author created: Aleksandra Maurina', '2025-05-27 13:16:45', NULL),
('234', '1', 'update_author', 'Author updated: \'Aleksandra Maurina\' to \'Aleksandra Maurinaa\'', '2025-05-27 13:16:56', NULL),
('235', '1', 'update_author', 'Author updated: \'Aleksandra Maurinaa\' to \'Aleksandra Maurinaa\'', '2025-05-27 13:16:56', NULL),
('236', '1', 'create_author', 'Author created: Aleksandra Maurina', '2025-05-27 13:17:05', NULL),
('237', '1', 'delete_author', 'Author deleted: Aleksandra Maurina', '2025-05-27 13:17:19', NULL),
('238', '1', 'delete_author', 'Author deleted: Aleksandra Maurinaa', '2025-05-27 13:17:21', NULL),
('239', '1', 'create_author', 'Author created: Aleksandra Maurina', '2025-05-27 13:17:23', NULL),
('240', '1', 'update_author', 'Author updated: \'Aleksandra Maurina\' to \'Aleksandra Maurina\'', '2025-05-27 13:17:46', NULL),
('241', '1', 'update_author', 'Author updated: \'Aleksandra Maurina\' to \'Aleksandra Maurinaa\'', '2025-05-27 13:17:54', NULL),
('242', '1', 'create_author', 'Author created: Aleksandra Maurina', '2025-05-27 13:17:57', NULL),
('243', '1', 'delete_author', 'Author deleted: Aleksandra Maurinaa', '2025-05-27 13:18:01', NULL),
('244', '1', 'logout', 'User logged out: Admin', '2025-05-27 13:32:08', NULL),
('245', '3', 'login', 'Successful login for user: Redaktor', '2025-05-27 13:32:13', NULL),
('247', '3', 'logout', 'User logged out: Redaktor', '2025-05-27 13:32:28', NULL),
('248', '1', 'login', 'Successful login for user: Admin', '2025-05-27 13:32:34', NULL),
('249', '1', 'logout', 'User logged out: Admin', '2025-05-27 13:41:34', NULL),
('250', '3', 'login', 'Successful login for user: Redaktor', '2025-05-27 13:41:40', NULL),
('251', '3', 'logout', 'User logged out: Redaktor', '2025-05-27 13:42:14', NULL),
('252', '1', 'login', 'Successful login for user: Admin', '2025-05-27 13:42:19', NULL),
('256', '1', 'logout', 'User logged out: Admin', '2025-05-27 19:28:53', NULL),
('257', '1', 'login', 'Successful login for user: Admin', '2025-05-27 19:28:57', NULL),
('258', '1', 'create_author', 'Author created: Aleksandra Maurina 2', '2025-05-27 20:21:18', NULL),
('259', '1', 'delete_image', 'Raderade produktbild med ID: 4', '2025-05-27 20:41:05', NULL),
('267', '1', 'update', 'Uppdaterade produkt: 1984', '2025-05-28 00:37:59', NULL),
('268', '1', 'update', 'Uppdaterade produkt: I, Robot', '2025-05-28 00:39:47', NULL),
('269', '1', 'update', 'Uppdaterade produkt: Afrikan tähti', '2025-05-28 00:42:16', NULL),
('270', '1', 'update', 'Uppdaterade produkt: Dungeons & Dragons Basic Set', '2025-05-28 00:42:52', NULL),
('271', '1', 'update', 'Uppdaterade produkt: Monopol Helsingfors edition', '2025-05-28 00:43:47', NULL),
('272', '1', 'update', 'Uppdaterade produkt: Trivial Pursuit Svenska', '2025-05-28 00:44:10', NULL),
('273', '1', 'logout', 'User logged out: Admin', '2025-05-28 05:39:20', NULL),
('274', '1', 'login', 'Successful login for user: Admin', '2025-05-28 06:11:54', NULL),
('275', '1', 'create', 'Skapade produkt: AAAA', '2025-05-28 06:12:21', NULL),
('276', '1', 'batch_delete', 'Batch operation: 1 produkter har tagits bort.', '2025-05-28 06:13:33', NULL),
('277', '1', 'batch_set_special_price', 'Batch operation: 7 produkter markerade som rea.', '2025-05-28 06:24:11', NULL),
('278', '1', 'batch_set_special_price', 'Batch operation: 3 produkter markerade som rea.', '2025-05-28 06:24:31', NULL),
('279', '1', 'logout', 'User logged out: Admin', '2025-05-28 07:53:40', NULL),
('280', '1', 'login', 'Successful login for user: Admin', '2025-05-28 07:56:15', NULL),
('281', '1', 'update', 'Uppdaterade produkt: Farlig midsommar', '2025-05-28 07:57:05', '27'),
('282', '1', 'update', 'Uppdaterade produkt: Pappan och havet', '2025-05-28 07:57:48', '29'),
('283', '1', 'update', 'Uppdaterade produkt: Trollvinter', '2025-05-28 07:58:34', '28'),
('284', '1', 'create', 'Skapade produkt: Product', '2025-05-28 08:06:45', NULL),
('285', '1', 'batch_delete', 'Batch operation: 1 produkter har tagits bort.', '2025-05-28 08:10:34', NULL),
('286', '1', 'logout', 'User logged out: Admin', '2025-05-28 08:20:52', NULL),
('287', '1', 'login', 'Successful login for user: Admin', '2025-05-28 08:29:44', NULL),
('288', '1', 'update', 'Uppdaterade produkt: 1984', '2025-05-28 08:32:10', NULL),
('289', '1', 'logout', 'User logged out: Admin', '2025-05-28 08:37:55', NULL),
('290', '3', 'login', 'Successful login for user: Redaktor', '2025-05-28 09:26:19', NULL),
('291', '3', 'sell', 'Produkt markerad som såld: 1984', '2025-05-28 09:26:42', NULL),
('292', '3', 'return', 'Produkt återställd till tillgänglig: 1984', '2025-05-28 09:26:45', NULL),
('293', '3', 'update', 'Uppdaterade produkt: Antique book binding tools', '2025-05-28 09:28:45', NULL),
('294', '3', 'create', 'Skapade produkt: Produkt', '2025-05-28 09:35:30', '153'),
('295', '3', 'update', 'Uppdaterade produkt: A Night at the Opera', '2025-05-28 09:37:47', '79'),
('296', '3', 'create_author', 'Author created: Aleksandra Maurina', '2025-05-28 09:38:25', NULL),
('297', '3', 'update_author', 'Author updated: \'Aleksandra\' to \'Aleksandra M\'', '2025-05-28 09:46:19', NULL),
('298', '3', 'batch_set_recommended', 'Batch operation: 77 produkter tog bort rekommendation från.', '2025-05-28 09:48:42', NULL),
('299', '3', 'logout', 'User logged out: Redaktor', '2025-05-28 10:00:54', NULL),
('300', '1', 'login', 'Successful login for user: Admin', '2025-05-28 10:01:18', NULL),
('301', '1', 'sell', 'Produkt markerad som såld: Emil i Lönneberga', '2025-05-28 10:01:36', '18'),
('302', '1', 'batch_update_status', 'Batch operation: 3 produkter har fått ny status.', '2025-05-28 10:01:58', NULL),
('303', '1', 'logout', 'User logged out: Admin', '2025-05-28 10:15:09', NULL),
('304', '1', 'login', 'Successful login for user: Admin', '2025-05-28 10:28:50', NULL),
('305', '1', 'logout', 'User logged out: Admin', '2025-05-28 13:46:36', NULL),
('306', '1', 'login', 'Successful login for user: Admin', '2025-06-02 11:02:33', NULL),
('307', '1', 'batch_delete', 'Batch operation: 85 produkter har tagits bort.', '2025-06-02 11:22:31', NULL);

-- 
-- Table structure for table `genre`
-- 

DROP TABLE IF EXISTS `genre`;
CREATE TABLE `genre` (
  `genre_id` int NOT NULL AUTO_INCREMENT,
  `genre_sv_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `genre_fi_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`genre_id`),
  UNIQUE KEY `genre_name` (`genre_sv_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `genre`
-- 

INSERT INTO `genre` (`genre_id`, `genre_sv_name`, `genre_fi_name`) VALUES
('1', 'Romaner', 'Romaanit'),
('3', 'Historia', 'Historia'),
('4', 'Dikter', 'Runot'),
('5', 'Biografi', 'Elämäkerta'),
('6', 'Barnböcker', 'Lastenkirjat'),
('7', 'Rock', 'Rock'),
('8', 'Jazz', 'Jazz'),
('9', 'Klassisk', 'Klassinen'),
('10', 'Äventyr', 'Seikkailu'),
('11', '-', '-');

-- 
-- Table structure for table `image`
-- 

DROP TABLE IF EXISTS `image`;
CREATE TABLE `image` (
  `image_id` int NOT NULL AUTO_INCREMENT,
  `prod_id` int DEFAULT NULL,
  `image_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `image_uploaded_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`image_id`),
  UNIQUE KEY `image_path` (`image_path`),
  KEY `fk_image_product` (`prod_id`),
  CONSTRAINT `fk_image_product` FOREIGN KEY (`prod_id`) REFERENCES `product` (`prod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=284 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `image`
-- 

INSERT INTO `image` (`image_id`, `prod_id`, `image_path`, `image_uploaded_at`) VALUES
('16', '16', 'assets/uploads/products/ka-child-01.webp', '2025-05-28 06:35:00'),
('17', '17', 'assets/uploads/products/ka-child-02.webp', '2025-05-28 06:35:00'),
('18', '18', 'assets/uploads/products/ka-child-03.webp', '2025-05-28 06:35:00'),
('19', '19', 'assets/uploads/products/ka-child-04.webp', '2025-05-28 06:35:00'),
('26', '26', 'assets/uploads/products/ka-child-05.webp', '2025-05-28 06:35:00'),
('30', '30', 'assets/uploads/products/ka-child-09.webp', '2025-05-28 06:35:00'),
('50', '50', 'assets/uploads/products/ka-child-10.webp', '2025-05-28 06:35:00'),
('57', '57', 'assets/uploads/products/ka-child-11.webp', '2025-05-28 06:35:00'),
('58', '58', 'assets/uploads/products/ka-child-12.webp', '2025-05-28 06:35:00'),
('59', '59', 'assets/uploads/products/ka-child-13.webp', '2025-05-28 06:35:00'),
('60', '60', 'assets/uploads/products/ka-child-14.webp', '2025-05-28 06:35:00'),
('66', '66', 'assets/uploads/products/ka-cd-01.webp', '2025-05-28 06:35:00'),
('67', '67', 'assets/uploads/products/ka-cd-02.webp', '2025-05-28 06:35:00'),
('68', '68', 'assets/uploads/products/ka-cd-03.webp', '2025-05-28 06:35:00'),
('69', '69', 'assets/uploads/products/ka-cd-04.webp', '2025-05-28 06:35:00'),
('70', '70', 'assets/uploads/products/ka-cd-05.webp', '2025-05-28 06:35:00'),
('71', '71', 'assets/uploads/products/ka-cd-06.webp', '2025-05-28 06:35:00'),
('72', '72', 'assets/uploads/products/ka-cd-07.webp', '2025-05-28 06:35:00'),
('73', '73', 'assets/uploads/products/ka-cd-08.webp', '2025-05-28 06:35:00'),
('74', '74', 'assets/uploads/products/ka-cd-09.webp', '2025-05-28 06:35:00'),
('75', '75', 'assets/uploads/products/ka-cd-10.webp', '2025-05-28 06:35:00'),
('76', '76', 'assets/uploads/products/ka-cd-11.webp', '2025-05-28 06:35:00'),
('77', '77', 'assets/uploads/products/ka-cd-12.webp', '2025-05-28 06:35:00'),
('78', '78', 'assets/uploads/products/ka-cd-13.webp', '2025-05-28 06:35:00'),
('79', '79', 'assets/uploads/products/ka-cd-14.webp', '2025-05-28 06:35:00'),
('80', '80', 'assets/uploads/products/ka-cd-15.webp', '2025-05-28 06:35:00'),
('81', '81', 'assets/uploads/products/ka-cd-16.webp', '2025-05-28 06:35:00'),
('82', '82', 'assets/uploads/products/ka-cd-17.webp', '2025-05-28 06:35:00'),
('83', '83', 'assets/uploads/products/ka-cd-18.webp', '2025-05-28 06:35:00'),
('84', '84', 'assets/uploads/products/ka-cd-19.webp', '2025-05-28 06:35:00'),
('85', '85', 'assets/uploads/products/ka-random-13.webp', '2025-05-28 06:35:00'),
('86', '86', 'assets/uploads/products/ka-random-14.webp', '2025-05-28 06:35:00'),
('87', '87', 'assets/uploads/products/ka-random-15.webp', '2025-05-28 06:35:00'),
('88', '88', 'assets/uploads/products/ka-random-16.webp', '2025-05-28 06:35:00'),
('89', '89', 'assets/uploads/products/ka-random-17.webp', '2025-05-28 06:35:00'),
('90', '90', 'assets/uploads/products/ka-random-18.webp', '2025-05-28 06:35:00'),
('91', '91', 'assets/uploads/products/ka-random-19.webp', '2025-05-28 06:35:00'),
('92', '92', 'assets/uploads/products/ka-random-20.webp', '2025-05-28 06:35:00'),
('93', '93', 'assets/uploads/products/ka-random-21.webp', '2025-05-28 06:35:00'),
('94', '94', 'assets/uploads/products/ka-random-22.webp', '2025-05-28 06:35:00'),
('95', '95', 'assets/uploads/products/ka-random-23.webp', '2025-05-28 06:35:00'),
('96', '96', 'assets/uploads/products/ka-random-24.webp', '2025-05-28 06:35:00'),
('97', '97', 'assets/uploads/products/ka-random-25.webp', '2025-05-28 06:35:00'),
('98', '98', 'assets/uploads/products/ka-random-26.webp', '2025-05-28 06:35:00'),
('99', '99', 'assets/uploads/products/ka-random-27.webp', '2025-05-28 06:35:00'),
('100', '100', 'assets/uploads/products/ka-random-28.webp', '2025-05-28 06:35:00'),
('101', '101', 'assets/uploads/products/ka-object-01.webp', '2025-05-28 06:35:00'),
('103', '103', 'assets/uploads/products/ka-object-03.webp', '2025-05-28 06:35:00'),
('111', '111', 'assets/uploads/products/ka-object-11.webp', '2025-05-28 06:35:00'),
('112', '112', 'assets/uploads/products/ka-object-12.webp', '2025-05-28 06:35:00'),
('115', '115', 'assets/uploads/products/ka-random-31.webp', '2025-05-28 06:35:00'),
('120', '120', 'assets/uploads/products/ka-child-19.webp', '2025-05-28 06:35:00'),
('122', '122', 'assets/uploads/products/ka-child-21.webp', '2025-05-28 06:35:00'),
('123', '123', 'assets/uploads/products/ka-child-22.webp', '2025-05-28 06:35:00'),
('130', '130', 'assets/uploads/products/ka-random-38.webp', '2025-05-28 06:35:00'),
('136', '136', 'assets/uploads/products/ka-random-44.webp', '2025-05-28 06:35:00'),
('138', '138', 'assets/uploads/products/ka-random-46.webp', '2025-05-28 06:35:00'),
('146', '146', 'assets/uploads/products/ka-random-50.webp', '2025-05-28 06:35:00'),
('147', '147', 'assets/uploads/products/ka-random-51.webp', '2025-05-28 06:35:00'),
('148', '148', 'assets/uploads/products/ka-random-52.webp', '2025-05-28 06:35:00'),
('149', '149', 'assets/uploads/products/ka-random-53.webp', '2025-05-28 06:35:00'),
('150', '150', 'assets/uploads/products/ka-random-54.webp', '2025-05-28 06:35:00'),
('166', '17', 'assets/uploads/products/ka-random-70.webp', '2025-05-28 06:35:00'),
('167', '17', 'assets/uploads/products/ka-random-71.webp', '2025-05-28 06:35:00'),
('168', '17', 'assets/uploads/products/ka-random-72.webp', '2025-05-28 06:35:00'),
('169', '17', 'assets/uploads/products/ka-random-73.webp', '2025-05-28 06:35:00'),
('176', '27', 'assets/uploads/products/ka-random-80.webp', '2025-05-28 06:35:00'),
('177', '27', 'assets/uploads/products/ka-random-81.webp', '2025-05-28 06:35:00'),
('178', '27', 'assets/uploads/products/ka-random-82.webp', '2025-05-28 06:35:00'),
('179', '27', 'assets/uploads/products/ka-random-83.webp', '2025-05-28 06:35:00'),
('180', '30', 'assets/uploads/products/ka-random-84.webp', '2025-05-28 06:35:00'),
('181', '30', 'assets/uploads/products/ka-random-85.webp', '2025-05-28 06:35:00'),
('205', '59', 'assets/uploads/products/ka-random-109.webp', '2025-05-28 06:35:00'),
('210', '67', 'assets/uploads/products/ka-random-114.webp', '2025-05-28 06:35:00'),
('211', '67', 'assets/uploads/products/ka-random-115.webp', '2025-05-28 06:35:00'),
('212', '70', 'assets/uploads/products/ka-random-116.webp', '2025-05-28 06:35:00'),
('213', '70', 'assets/uploads/products/ka-random-117.webp', '2025-05-28 06:35:00'),
('214', '70', 'assets/uploads/products/ka-random-118.webp', '2025-05-28 06:35:00'),
('215', '74', 'assets/uploads/products/ka-random-119.webp', '2025-05-28 06:35:00'),
('216', '77', 'assets/uploads/products/ka-random-120.webp', '2025-05-28 06:35:00'),
('217', '77', 'assets/uploads/products/ka-random-121.webp', '2025-05-28 06:35:00'),
('218', '77', 'assets/uploads/products/ka-random-122.webp', '2025-05-28 06:35:00'),
('219', '77', 'assets/uploads/products/ka-random-123.webp', '2025-05-28 06:35:00'),
('220', '79', 'assets/uploads/products/ka-random-124.webp', '2025-05-28 06:35:00'),
('221', '79', 'assets/uploads/products/ka-random-125.webp', '2025-05-28 06:35:00'),
('222', '80', 'assets/uploads/products/ka-random-126.webp', '2025-05-28 06:35:00'),
('223', '80', 'assets/uploads/products/ka-random-127.webp', '2025-05-28 06:35:00'),
('224', '80', 'assets/uploads/products/ka-random-128.webp', '2025-05-28 06:35:00'),
('225', '85', 'assets/uploads/products/ka-random-129.webp', '2025-05-28 06:35:00'),
('226', '92', 'assets/uploads/products/ka-random-130.webp', '2025-05-28 06:35:00'),
('227', '92', 'assets/uploads/products/ka-random-131.webp', '2025-05-28 06:35:00'),
('228', '92', 'assets/uploads/products/ka-random-132.webp', '2025-05-28 06:35:00'),
('229', '92', 'assets/uploads/products/ka-random-133.webp', '2025-05-28 06:35:00'),
('230', '95', 'assets/uploads/products/ka-random-134.webp', '2025-05-28 06:35:00'),
('231', '95', 'assets/uploads/products/ka-random-135.webp', '2025-05-28 06:35:00'),
('232', '99', 'assets/uploads/products/ka-random-136.webp', '2025-05-28 06:35:00'),
('233', '99', 'assets/uploads/products/ka-random-137.webp', '2025-05-28 06:35:00'),
('234', '99', 'assets/uploads/products/ka-random-138.webp', '2025-05-28 06:35:00'),
('235', '101', 'assets/uploads/products/ka-random-139.webp', '2025-05-28 06:35:00'),
('245', '115', 'assets/uploads/products/ka-random-149.webp', '2025-05-28 06:35:00');

INSERT INTO `image` (`image_id`, `prod_id`, `image_path`, `image_uploaded_at`) VALUES
('266', '147', 'assets/uploads/products/ka-random-170.webp', '2025-05-28 06:35:00'),
('267', '147', 'assets/uploads/products/ka-random-171.webp', '2025-05-28 06:35:00'),
('268', '147', 'assets/uploads/products/ka-random-172.webp', '2025-05-28 06:35:00'),
('269', '147', 'assets/uploads/products/ka-random-173.webp', '2025-05-28 06:35:00'),
('270', '149', 'assets/uploads/products/ka-random-174.webp', '2025-05-28 06:35:00'),
('271', '149', 'assets/uploads/products/ka-random-175.webp', '2025-05-28 06:35:00'),
('272', '150', 'assets/uploads/products/ka-random-176.webp', '2025-05-28 06:35:00'),
('273', '150', 'assets/uploads/products/ka-random-177.webp', '2025-05-28 06:35:00'),
('274', '150', 'assets/uploads/products/ka-random-178.webp', '2025-05-28 06:35:00'),
('275', '29', 'assets/uploads/products/29_683697c9c6c5b_1748408265.webp', '2025-05-28 07:57:47'),
('276', '29', 'assets/uploads/products/29_683697cb0c9e5_1748408267.webp', '2025-05-28 07:57:48'),
('277', '28', 'assets/uploads/products/28_683697f8279a3_1748408312.webp', '2025-05-28 07:58:33'),
('278', '28', 'assets/uploads/products/28_683697f946858_1748408313.webp', '2025-05-28 07:58:34'),
('280', '153', 'assets/uploads/products/153_6836aeb20bf68_1748414130.webp', '2025-05-28 09:35:31'),
('281', '153', 'assets/uploads/products/153_6836aeb32605b_1748414131.webp', '2025-05-28 09:35:31'),
('282', '153', 'assets/uploads/products/153_6836aeb3e7e61_1748414131.webp', '2025-05-28 09:35:32'),
('283', '153', 'assets/uploads/products/153_6836aeb4d4d82_1748414132.webp', '2025-05-28 09:35:33');

-- 
-- Table structure for table `language`
-- 

DROP TABLE IF EXISTS `language`;
CREATE TABLE `language` (
  `language_id` int NOT NULL AUTO_INCREMENT,
  `language_sv_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `language_fi_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`language_id`),
  UNIQUE KEY `language_sv_name` (`language_sv_name`),
  UNIQUE KEY `language_fi_name` (`language_fi_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `language`
-- 

INSERT INTO `language` (`language_id`, `language_sv_name`, `language_fi_name`) VALUES
('1', 'Svenska', 'Ruotsi'),
('2', 'Finska', 'Suomi'),
('3', 'Engelska', 'Englanti'),
('4', 'Norska', 'Norja'),
('5', 'Tyska', 'Saksa'),
('6', 'Ryska', 'Venäjä'),
('7', 'Franska', 'Ranska'),
('8', 'Spanska', 'Espanja');

-- 
-- Table structure for table `newsletter_subscriber`
-- 

DROP TABLE IF EXISTS `newsletter_subscriber`;
CREATE TABLE `newsletter_subscriber` (
  `subscriber_id` int NOT NULL AUTO_INCREMENT,
  `subscriber_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `subscriber_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subscribed_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `subscriber_is_active` tinyint(1) DEFAULT '1',
  `subscriber_language_pref` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'sv',
  PRIMARY KEY (`subscriber_id`),
  UNIQUE KEY `subscriber_email` (`subscriber_email`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `newsletter_subscriber`
-- 

INSERT INTO `newsletter_subscriber` (`subscriber_id`, `subscriber_email`, `subscriber_name`, `subscribed_date`, `subscriber_is_active`, `subscriber_language_pref`) VALUES
('1', 'johanna.karlsson@example.com', 'Johanna Karlsson', '2025-05-13 12:37:38', '0', 'sv'),
('2', 'mikko.nieminen@example.fi', 'Mikko Nieminen', '2025-05-13 12:37:38', '1', 'fi'),
('3', 'anna.lindholm@example.com', 'Anna Lindholm', '2025-05-13 12:37:38', '1', 'sv'),
('4', 'erik.johansson@example.se', 'Erik Johansson', '2025-05-13 12:37:38', '1', 'sv'),
('5', 'liisa.makinen@example.fi', 'Liisa Mäkinen', '2025-05-13 12:37:38', '1', 'fi'),
('6', 'bengt.gustafsson@example.com', 'Bengt Gustafsson', '2025-05-13 12:37:38', '1', 'sv'),
('7', 'aino.virtanen@gmail.com', 'Aino Virtanen', '2025-01-15 10:30:00', '1', 'fi'),
('8', 'lars.andersson@hotmail.com', 'Lars Andersson', '2025-01-18 14:22:00', '1', 'sv'),
('9', 'maria.korhonen@yahoo.fi', 'Maria Korhonen', '2025-01-20 09:15:00', '1', 'fi'),
('10', 'erik.johansson@gmail.com', 'Erik Johansson', '2025-01-22 16:45:00', '1', 'sv'),
('11', 'helena.nieminen@outlook.com', 'Helena Nieminen', '2025-01-25 11:30:00', '1', 'fi'),
('12', 'sven.karlsson@telia.com', 'Sven Karlsson', '2025-01-28 13:20:00', '1', 'sv'),
('13', 'liisa.hakkarainen@gmail.com', 'Liisa Hakkarainen', '2025-02-01 10:00:00', '1', 'fi'),
('14', 'anna.lindberg@hotmail.se', 'Anna Lindberg', '2025-02-03 15:30:00', '1', 'sv'),
('15', 'mikko.salminen@elisa.fi', 'Mikko Salminen', '2025-02-05 12:45:00', '1', 'fi'),
('16', 'ingrid.gustafsson@gmail.com', 'Ingrid Gustafsson', '2025-02-08 09:20:00', '1', 'sv'),
('17', 'kari.laine@luukku.com', 'Kari Laine', '2025-02-10 14:15:00', '1', 'fi'),
('18', 'gunnar.pettersson@spray.se', 'Gunnar Pettersson', '2025-02-12 16:00:00', '1', 'sv'),
('19', 'tuula.heikkinen@gmail.com', 'Tuula Heikkinen', '2025-02-15 11:45:00', '1', 'fi'),
('20', 'astrid.nilsson@yahoo.se', 'Astrid Nilsson', '2025-02-17 13:30:00', '1', 'sv'),
('21', 'pekka.virtanen@saunalahti.fi', 'Pekka Virtanen', '2025-02-20 10:20:00', '1', 'fi'),
('22', 'margareta.holm@telia.se', 'Margareta Holm', '2025-02-22 15:10:00', '1', 'sv'),
('23', 'ritva.korhonen@kolumbus.fi', 'Ritva Korhonen', '2025-02-25 12:00:00', '1', 'fi'),
('24', 'nils.berg@gmail.com', 'Nils Berg', '2025-02-27 14:30:00', '1', 'sv'),
('25', 'riitta.makinen@hotmail.com', 'Riitta Mäkinen', '2025-03-01 09:45:00', '1', 'fi'),
('26', 'bengt.larsson@bredband.net', 'Bengt Larsson', '2025-03-03 16:20:00', '1', 'sv'),
('27', 'maija.koskinen@gmail.com', 'Maija Koskinen', '2025-03-05 11:15:00', '1', 'fi'),
('28', 'olof.stromberg@yahoo.se', 'Olof Strömberg', '2025-03-08 13:40:00', '1', 'sv'),
('29', 'elina.saarinen@elisa.fi', 'Elina Saarinen', '2025-03-10 10:30:00', '1', 'fi'),
('30', 'birgitta.hansson@gmail.com', 'Birgitta Hansson', '2025-03-12 15:50:00', '1', 'sv'),
('31', 'jukka.rantala@luukku.com', 'Jukka Rantala', '2025-03-15 12:25:00', '1', 'fi'),
('32', 'rolf.danielsson@telia.com', 'Rolf Danielsson', '2025-03-17 14:10:00', '1', 'sv'),
('33', 'sirpa.lahtinen@gmail.com', 'Sirpa Lahtinen', '2025-03-20 09:35:00', '1', 'fi'),
('34', 'ulla.hedberg@hotmail.se', 'Ulla Hedberg', '2025-03-22 16:15:00', '1', 'sv'),
('35', 'paavo.kallio@saunalahti.fi', 'Paavo Kallio', '2025-03-25 11:50:00', '1', 'fi'),
('36', 'gustav.lindqvist@gmail.com', 'Gustav Lindqvist', '2025-03-27 13:25:00', '1', 'sv'),
('37', 'anneli.harju@kolumbus.fi', 'Anneli Harju', '2025-04-01 10:40:00', '1', 'fi'),
('38', 'torsten.wickman@yahoo.se', 'Torsten Wickman', '2025-04-03 15:05:00', '1', 'sv'),
('39', 'kirsti.aalto@elisa.fi', 'Kirsti Aalto', '2025-04-05 12:20:00', '1', 'fi'),
('40', 'ragnar.sundberg@telia.se', 'Ragnar Sundberg', '2025-04-08 14:45:00', '1', 'sv'),
('41', 'terttu.virtanen@gmail.com', 'Terttu Virtanen', '2025-04-10 09:55:00', '1', 'fi'),
('43', 'lesya.maurin@gmail.com', 'Alexandra', '2025-05-28 09:23:02', '1', 'sv');

-- 
-- Table structure for table `product`
-- 

DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `prod_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` int DEFAULT NULL,
  `shelf_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `condition_id` int DEFAULT NULL,
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `internal_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `year` int DEFAULT NULL,
  `publisher` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `special_price` tinyint(1) DEFAULT NULL COMMENT 'Om produkten är på rea: 1 = Ja, 0 = Nej',
  `recommended` tinyint(1) DEFAULT NULL COMMENT 'Om produkten är rekommenderad: 1 = Ja, 0 = Nej	',
  `rare` tinyint(1) DEFAULT '0',
  `date_added` datetime DEFAULT CURRENT_TIMESTAMP,
  `language_id` int DEFAULT NULL,
  PRIMARY KEY (`prod_id`),
  KEY `shelf_id` (`shelf_id`),
  KEY `category_id` (`category_id`),
  KEY `condition_id` (`condition_id`),
  KEY `idx_product_status` (`status`),
  KEY `fk_product_language` (`language_id`),
  CONSTRAINT `fk_product_language` FOREIGN KEY (`language_id`) REFERENCES `language` (`language_id`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`shelf_id`) REFERENCES `shelf` (`shelf_id`),
  CONSTRAINT `product_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `product_ibfk_3` FOREIGN KEY (`condition_id`) REFERENCES `condition` (`condition_id`),
  CONSTRAINT `product_ibfk_4` FOREIGN KEY (`status`) REFERENCES `status` (`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `product`
-- 

INSERT INTO `product` (`prod_id`, `title`, `status`, `shelf_id`, `category_id`, `price`, `condition_id`, `notes`, `internal_notes`, `year`, `publisher`, `special_price`, `recommended`, `rare`, `date_added`, `language_id`) VALUES
('16', 'Pippi Långstrump', '2', '5', '1', '16.90', '1', 'Barnklassiker', 'Populär bland barn', '1945', 'Rabén & Sjögren', '0', '0', '0', '2025-05-28 00:26:26', '1'),
('17', 'Ronja rövardotter', '2', '5', '1', '18.50', '2', 'Fantasy för barn', NULL, '1981', 'Rabén & Sjögren', '1', '0', '0', '2025-05-28 00:26:26', '1'),
('18', 'Emil i Lönneberga', '2', '5', '1', '15.90', '1', 'Barnbok', NULL, '1963', 'Rabén & Sjögren', '0', '0', '0', '2025-05-28 00:26:26', '1'),
('19', 'Karlsson på taket', '2', '5', '1', '17.50', '2', 'Klassisk barnbok', NULL, '1955', 'Rabén & Sjögren', '1', '0', '0', '2025-05-28 00:26:26', '1'),
('26', 'Trollkarlens hatt', '1', '5', '1', '17.50', '1', 'Mumin klassiker', 'Illustrerad', '1948', 'Schildts', '0', '0', '0', '2025-05-28 00:26:26', '1'),
('27', 'Farlig midsommar', '1', '5', '1', '16.90', '2', 'Mumin äventyr', '', '1954', 'Schildts', '1', '0', '0', '2025-05-28 00:26:26', '1'),
('28', 'Trollvinter', '1', '5', '1', '18.50', '1', 'Mumin roman', '', '1957', 'Schildts', '0', '0', '0', '2025-05-28 00:26:26', '1'),
('29', 'Pappan och havet', '1', '5', '1', '17.90', '2', 'Mumin serie', '', '1965', 'Schildts', '1', '0', '0', '2025-05-28 00:26:26', '1'),
('30', 'Sent i november', '1', '5', '1', '19.50', '1', 'Sista Mumin boken', NULL, '1970', 'Schildts', '0', '0', '0', '2025-05-28 00:26:26', '1'),
('50', 'The Adventures of Tom Sawyer', '1', '5', '1', '16.50', '1', 'Ungdomsbok', NULL, '1876', 'Penguin', '0', '0', '0', '2025-05-28 00:26:26', '3'),
('57', 'Charlie and the Chocolate Factory', '1', '5', '1', '13.50', '1', 'Barnklassiker', NULL, '1964', 'Puffin', '0', '0', '0', '2025-05-28 00:26:26', '3'),
('58', 'Matilda', '1', '5', '1', '14.90', '2', 'Roald Dahl', NULL, '1988', 'Puffin', '1', '0', '0', '2025-05-28 00:26:26', '3'),
('59', 'Alice in Wonderland', '1', '5', '1', '15.50', '1', 'Fantasy klassiker', NULL, '1865', 'Penguin Classics', '0', '0', '0', '2025-05-28 00:26:26', '3'),
('60', 'The Lion, the Witch and the Wardrobe', '1', '5', '1', '16.50', '2', 'Narnia serie', NULL, '1950', 'HarperCollins', '1', '0', '0', '2025-05-28 00:26:26', '3'),
('66', 'Finlandia - Sibelius Greatest', '1', '6', '5', '18.90', '1', 'Klassisk samling', NULL, '1995', 'Ondine', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('67', 'Sibelius Symphonies 1-7', '1', '6', '5', '24.50', '2', 'Komplett', NULL, '2001', 'BIS', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('68', 'The Beatles - Abbey Road', '1', '6', '5', '22.50', '1', 'Klassiskt album', 'Remastrad', '1969', 'Apple', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('69', 'The Beatles - Sgt Pepper', '1', '6', '5', '21.90', '2', 'Psykedelisk klassiker', NULL, '1967', 'Parlophone', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('70', 'Elvis Presley - The Essential', '1', '6', '5', '21.00', '2', 'Rock n roll kung', NULL, '2007', 'RCA', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('71', 'Elvis - 30 #1 Hits', '1', '6', '5', '19.50', '1', 'Bästa hits', NULL, '2002', 'RCA', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('72', 'Bob Dylan - Greatest Hits', '1', '6', '5', '20.50', '1', 'Folk rock legend', NULL, '1967', 'Columbia', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('73', 'Blood on the Tracks', '1', '6', '5', '18.90', '2', 'Dylan klassiker', NULL, '1975', 'Columbia', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('74', 'ABBA Gold', '1', '6', '5', '19.90', '2', 'Bästa hits', 'Internationell succé', '1992', 'Polar', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('75', 'ABBA - Arrival', '1', '6', '5', '17.50', '1', 'Svenskt original', NULL, '1976', 'Polar', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('76', 'Pink Floyd - Dark Side of the Moon', '1', '6', '5', '23.50', '1', 'Prog rock klassiker', NULL, '1973', 'Harvest', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('77', 'The Wall', '1', '6', '5', '21.90', '2', 'Konceptalbum', NULL, '1979', 'Harvest', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('78', 'Queen - Greatest Hits', '1', '6', '5', '20.50', '1', 'Rock klassiker', NULL, '1981', 'EMI', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('79', 'A Night at the Opera', '1', '6', '5', '19.90', '2', 'Innehåller Bohemian Rhapsody', '', '1975', 'EMI', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('80', 'Led Zeppelin IV', '1', '6', '5', '22.50', '1', 'Hard rock klassiker', NULL, '1971', 'Atlantic', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('81', 'Physical Graffiti', '1', '6', '5', '24.50', '2', 'Dubbel-CD', NULL, '1975', 'Swan Song', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('82', 'David Bowie - The Rise and Fall', '1', '6', '5', '21.50', '1', 'Glam rock', NULL, '1972', 'RCA', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('83', 'Heroes', '1', '6', '5', '19.50', '2', 'Berlin trilogi', NULL, '1977', 'RCA', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('84', 'The Rolling Stones - Sticky Fingers', '1', '6', '5', '20.90', '1', 'Rock klassiker', NULL, '1971', 'Rolling Stones', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('85', 'Exile on Main St.', '1', '6', '5', '23.50', '2', 'Dubbel-CD', NULL, '1972', 'Rolling Stones', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('86', 'Juice Leskinen - Kootut levyt', '1', '6', '5', '24.50', '2', 'Finsk rocklegend', 'Komplett samling', '1989', 'Poko', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('87', 'Eppu Normaali - Akun tehdas', '1', '6', '5', '18.50', '1', 'Finsk punk rock', NULL, '1980', 'Poko', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('88', 'Dingo - Kerjäläisten valtakunta', '1', '6', '5', '16.50', '1', 'Kultalbum', NULL, '1986', 'Fazer', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('89', 'Hassisen Kone - Rumat sävelet', '1', '6', '5', '22.50', '2', 'Punk klassiker', NULL, '1982', 'Poko', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('90', 'Leevi and the Leavings - Menestyksen salaisuus', '1', '6', '5', '19.90', '1', 'Indie pop', NULL, '1991', 'Pyramid', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('91', 'Aki Kaurismäki Box Set', '1', '7', '7', '45.50', '1', 'Finsk filmsamling', 'Komplett box', '2005', 'Criterion', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('92', 'Ariel', '1', '7', '7', '16.50', '2', 'Kaurismäki klassiker', NULL, '1988', 'Villealfa', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('93', 'Leningrad Cowboys Go America', '1', '7', '7', '18.50', '1', 'Kultfilm', NULL, '1989', 'Villealfa', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('94', 'The Seventh Seal', '1', '7', '7', '22.50', '2', 'Bergman mästerverk', 'Criterion edition', '1957', 'Criterion', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('95', 'Persona', '1', '7', '7', '20.50', '1', 'Psykologiskt drama', NULL, '1966', 'Criterion', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('96', 'Jaws', '1', '7', '7', '15.50', '2', 'Thriller klassiker', NULL, '1975', 'Universal', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('97', 'E.T. the Extra-Terrestrial', '1', '7', '7', '14.90', '1', 'Sci-fi familj', NULL, '1982', 'Universal', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('98', 'Inception', '1', '7', '7', '18.50', '1', 'Sci-fi thriller', NULL, '2010', 'Warner Bros', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('99', 'The Dark Knight', '1', '7', '7', '17.90', '2', 'Superhero epos', NULL, '2008', 'Warner Bros', '0', '0', '0', '2025-05-28 00:26:26', NULL),
('100', 'Psycho', '1', '7', '7', '16.50', '3', 'Thriller klassiker', 'Äldre utgåva', '1960', 'Universal', '0', '0', '1', '2025-05-28 00:26:26', NULL),
('101', 'Vintage Helsinki postcard collection', '1', '3', '9', '45.00', '2', 'Gamla vykort 1920-1950', 'Historiskt värde', '1935', '', '0', '0', '1', '2025-05-28 00:32:42', NULL),
('103', 'Old map of Turku/Åbo', '1', '3', '9', '78.50', '2', 'Historisk stadskarta', '1800-talet original', '1889', 'Kartografiska', '0', '0', '1', '2025-05-28 00:32:42', NULL),
('111', 'Old compass and navigation tools', '1', '4', '9', '145.50', '2', 'Sjöfarts instrument', 'Mässing kompass 1920-tal', '1925', 'Maritime Instruments', '0', '0', '1', '2025-05-28 00:32:42', NULL),
('112', 'Vintage fishing equipment', '1', '4', '9', '78.90', '3', 'Gamla fiskeverktyg', 'Träspön och rullar', '1950', '', '0', '0', '0', '2025-05-28 00:32:42', NULL),
('115', 'Old ship model', '1', '4', '9', '225.50', '2', 'Handgjord skeppsmodell', 'Finsk ångbåt modell', '1960', '', '0', '0', '0', '2025-05-28 00:32:42', NULL),
('120', 'Kalle Anka pocket samling', '1', '5', '8', '45.50', '3', 'Svenska pockets 1980-tal', '20 exemplar', '1985', 'Egmont', '0', '0', '0', '2025-05-28 00:32:42', '1'),
('122', 'Spider-Man: Amazing Fantasy #15', '2', '1', '8', '450.00', '4', 'Första Spider-Man', 'Mycket sällsynt reprint', '1962', 'Marvel', '0', '1', '1', '2025-05-28 00:32:42', '3'),
('123', 'X-Men #1', '2', '1', '8', '125.50', '3', 'Första X-Men', 'Silverålder klassiker', '1963', 'Marvel', '0', '1', '1', '2025-05-28 00:32:42', '3'),
('130', 'Smurfarna: Det blå folket', '1', '5', '8', '16.50', '2', 'Peyo klassiker', 'Svenska', '1963', 'Dupuis', '1', '0', '0', '2025-05-28 00:32:42', '1'),
('136', 'Playboy vintage 1970s', '2', '1', '13', '85.50', '3', 'Klassiska nummer', 'Samlarobjekt', '1975', 'Playboy', '0', '0', '1', '2025-05-28 00:32:42', '3'),
('138', 'Historiallinen Aikakauskirja', '1', '3', '13', '38.90', '2', 'Historisk tidskrift', '1990-talet komplett', '1995', 'Suomen Historiallinen Seura', '0', '0', '0', '2025-05-28 00:32:42', '2'),
('146', 'Dark Side of the Moon vinyl', '1', '6', '6', '85.50', '2', 'Pink Floyd original pressning', 'UK original 1973', '1973', 'Harvest', '0', '0', '1', '2025-05-28 00:32:42', NULL),
('147', 'Abbey Road original vinyl', '1', '6', '6', '125.00', '1', 'Beatles original pressning', 'UK Parlophone 1969', '1969', 'Apple', '0', '0', '1', '2025-05-28 00:32:42', NULL),
('148', 'ABBA - Waterloo vinyl', '1', '6', '6', '45.50', '2', 'Eurovision vinnare', 'Svenskt original 1974', '1974', 'Polar', '0', '0', '0', '2025-05-28 00:32:42', NULL),
('149', 'Led Zeppelin IV vinyl', '1', '6', '6', '78.90', '1', 'Zoso album original', 'Atlantic original 1971', '1971', 'Atlantic', '0', '0', '0', '2025-05-28 00:32:42', NULL),
('150', 'Juice Leskinen - Kala, kala, kala', '1', '6', '6', '65.00', '2', 'Finsk rock vinyl', 'Love Records original', '1978', 'Love Records', '0', '0', '1', '2025-05-28 00:32:42', NULL),
('153', 'Produkt', '1', NULL, '1', NULL, NULL, '', '', NULL, '', '0', '0', '0', '2025-05-28 09:35:29', NULL);

-- 
-- Table structure for table `product_author`
-- 

DROP TABLE IF EXISTS `product_author`;
CREATE TABLE `product_author` (
  `product_author_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int DEFAULT NULL,
  `author_id` int DEFAULT NULL,
  PRIMARY KEY (`product_author_id`),
  UNIQUE KEY `unique_product_author` (`product_id`,`author_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `product_author_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`prod_id`),
  CONSTRAINT `product_author_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `author` (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `product_author`
-- 

INSERT INTO `product_author` (`product_author_id`, `product_id`, `author_id`) VALUES
('16', '16', '6'),
('17', '17', '6'),
('18', '18', '6'),
('19', '19', '6'),
('26', '26', '9'),
('127', '27', '9'),
('129', '28', '9'),
('128', '29', '9'),
('30', '30', '9'),
('50', '50', '20'),
('57', '57', '26'),
('58', '58', '26'),
('59', '59', '27'),
('60', '60', '28'),
('66', '66', '31'),
('67', '67', '31'),
('68', '68', '32'),
('69', '69', '32'),
('70', '70', '33'),
('71', '71', '33'),
('72', '72', '34'),
('73', '73', '34'),
('74', '74', '35'),
('75', '75', '35'),
('76', '76', '36'),
('77', '77', '36'),
('78', '78', '37'),
('134', '79', '37'),
('135', '79', '67'),
('80', '80', '38'),
('81', '81', '38'),
('82', '82', '39'),
('83', '83', '39'),
('84', '84', '40'),
('85', '85', '40'),
('86', '86', '41'),
('87', '87', '42'),
('88', '88', '43'),
('89', '89', '44'),
('90', '90', '45'),
('91', '91', '46'),
('92', '92', '46'),
('93', '93', '46'),
('94', '94', '47'),
('95', '95', '47'),
('96', '96', '48'),
('97', '97', '48'),
('98', '98', '49'),
('99', '99', '49'),
('100', '100', '50'),
('107', '120', '54'),
('109', '122', '56'),
('110', '122', '57'),
('111', '123', '56'),
('112', '123', '57'),
('119', '130', '65'),
('120', '146', '36'),
('121', '147', '32'),
('122', '148', '35'),
('123', '149', '38'),
('124', '150', '41');

-- 
-- Table structure for table `product_genre`
-- 

DROP TABLE IF EXISTS `product_genre`;
CREATE TABLE `product_genre` (
  `product_genre_id` int NOT NULL AUTO_INCREMENT,
  `product_id` int DEFAULT NULL,
  `genre_id` int DEFAULT NULL,
  PRIMARY KEY (`product_genre_id`),
  UNIQUE KEY `unique_product_genre` (`product_id`,`genre_id`),
  KEY `genre_id` (`genre_id`),
  CONSTRAINT `product_genre_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`prod_id`),
  CONSTRAINT `product_genre_ibfk_2` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`genre_id`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `product_genre`
-- 

INSERT INTO `product_genre` (`product_genre_id`, `product_id`, `genre_id`) VALUES
('16', '16', '6'),
('17', '17', '6'),
('18', '18', '6'),
('19', '19', '6'),
('26', '26', '6'),
('157', '27', '6'),
('159', '28', '6'),
('158', '29', '6'),
('30', '30', '6'),
('50', '50', '1'),
('57', '57', '6'),
('58', '58', '6'),
('59', '59', '6'),
('60', '60', '6'),
('66', '66', '9'),
('67', '67', '9'),
('68', '68', '7'),
('69', '69', '7'),
('70', '70', '7'),
('71', '71', '7'),
('72', '72', '7'),
('73', '73', '7'),
('74', '74', '7'),
('75', '75', '7'),
('76', '76', '7'),
('77', '77', '7'),
('78', '78', '7'),
('162', '79', '7'),
('80', '80', '7'),
('81', '81', '7'),
('82', '82', '7'),
('83', '83', '7'),
('84', '84', '7'),
('85', '85', '7'),
('86', '86', '7'),
('87', '87', '7'),
('88', '88', '7'),
('89', '89', '7'),
('90', '90', '7'),
('91', '91', '10'),
('92', '92', '10'),
('93', '93', '10'),
('94', '94', '10'),
('95', '95', '10'),
('96', '96', '10'),
('97', '97', '10'),
('98', '98', '10'),
('99', '99', '10'),
('100', '100', '10'),
('101', '101', '11'),
('103', '103', '11'),
('111', '111', '11'),
('112', '112', '11'),
('115', '115', '11'),
('120', '120', '6'),
('122', '122', '10'),
('123', '123', '10'),
('130', '130', '6'),
('136', '136', '11'),
('138', '138', '3'),
('146', '146', '7'),
('147', '147', '7'),
('148', '148', '7'),
('149', '149', '7'),
('150', '150', '7');

-- 
-- Table structure for table `shelf`
-- 

DROP TABLE IF EXISTS `shelf`;
CREATE TABLE `shelf` (
  `shelf_id` int NOT NULL AUTO_INCREMENT,
  `shelf_sv_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `shelf_fi_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`shelf_id`),
  UNIQUE KEY `shelf_name` (`shelf_sv_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `shelf`
-- 

INSERT INTO `shelf` (`shelf_id`, `shelf_sv_name`, `shelf_fi_name`) VALUES
('1', 'Finlandssvenska', 'Suomenruotsalainen'),
('3', 'Lokalhistoria', 'Paikallishistoria'),
('4', 'Sjöfart', 'Merenkulku'),
('5', 'Barn/Ungdom', 'Lapset/Nuoret'),
('6', 'Musik', 'Musiikki'),
('7', 'Film', 'Elokuva');

-- 
-- Table structure for table `status`
-- 

DROP TABLE IF EXISTS `status`;
CREATE TABLE `status` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `status_sv_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status_fi_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`status_id`),
  UNIQUE KEY `status_name` (`status_sv_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `status`
-- 

INSERT INTO `status` (`status_id`, `status_sv_name`, `status_fi_name`) VALUES
('1', 'Tillgänglig', 'Saatavilla'),
('2', 'Såld', 'Myyty');

-- 
-- Table structure for table `user`
-- 

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_role` int NOT NULL DEFAULT '3',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `user_last_login` datetime DEFAULT NULL,
  `user_created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_username` (`user_username`),
  UNIQUE KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` (`user_id`, `user_username`, `user_password_hash`, `user_role`, `user_email`, `user_last_login`, `user_created_at`, `user_is_active`) VALUES
('1', 'Admin', '$2y$10$J0jSNdu1QUebZT4KRq6yTOkwFQ4DyyIqO8Lj/o5KZuSTXUQ1MgCgu', '1', 'admin@karisantikvariat.fi', '2025-06-02 11:02:33', '2025-04-10 10:41:05', '1'),
('3', 'Redaktor', '$2y$10$Qx1YgizfEOSuzTAp3r5bd.qfGJbMcXjdneHL9Ge9icsPbIsm5uicO', '2', 'redaktor@karisantikvariat.fi', '2025-05-28 09:26:19', '2025-04-30 13:57:26', '1');

SET FOREIGN_KEY_CHECKS = 1;
